package com.food;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodDeliveryProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

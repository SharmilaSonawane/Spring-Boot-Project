package com.food.dao;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Item {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer itemId;
	@NotBlank(message="Please Enter itemName")
	private String itemName;
	@Column(nullable = false)
	private Integer quantity;
	@Column(nullable = false)
	private Double cost;
	
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="cartid" , referencedColumnName = "cartid")
	Foodcart foodcart;
	
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="restaurantId" , referencedColumnName = "restaurantId")
	Restaurant restaurant;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="categoryId")
	private Category category;
	
	
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(String itemName, Integer quantity, Double cost) {
		super();
		this.itemName = itemName;
		this.quantity = quantity;
		this.cost = cost;
	}
	
	
	
	
	public Foodcart getFoodcart() {
		return foodcart;
	}
	public void setFoodcart(Foodcart foodcart) {
		this.foodcart = foodcart;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", quantity=" + quantity + ", cost=" + cost + "]";
	}
	public void assignItemToFoodcart(Foodcart fcart) {
		// TODO Auto-generated method stub
		this.foodcart=fcart;	
	}
	public void assignItemToCategory(Category catgy) {
		// TODO Auto-generated method stub
		 this.category=catgy;	
	}
	public void assignItemToRestaurant(Restaurant rest) {
		// TODO Auto-generated method stub
		this.restaurant=rest;
	}
	
	

}

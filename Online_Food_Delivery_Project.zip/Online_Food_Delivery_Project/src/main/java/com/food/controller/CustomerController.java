package com.food.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.food.dao.Customer;
import com.food.error.GlobalExceptionHandling;
import com.food.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	  private CustomerService customerService;
	
//	  @PostMapping("/CustomerRegistration")
//	  public Customer saveCustomerDetails(@RequestBody Customer customer) {
//		return customerService.saveCustomerDetails(customer);
//		   
//	   }
	
	@PostMapping("/CustomerRegistration")
	public ResponseEntity<Customer> saveCustomer(@Valid @RequestBody Customer customer)
	{
		Customer cust=customerService.saveCustomerDetails(customer);
		return new ResponseEntity<Customer>(cust, HttpStatus.CREATED);	
	}
	
	@PutMapping("/updateCustomerById/{cid}")
	public Customer updateCustomer(@PathVariable("cid") Integer customerid,@RequestBody Customer customer) throws GlobalExceptionHandling {
		return customerService.updateCustomerById(customerid,customer);
		
	}
	
	@GetMapping("/viewCustomerById/{cid}")
	public Customer viewCustomerById(@PathVariable ("cid") Integer customerid) throws GlobalExceptionHandling
	{
		return customerService.viewCustomerById(customerid);
	}
	
	@DeleteMapping("/deleteCustomerById/{cid}")
	public String deleteCustomerById(@PathVariable ("cid") Integer customerid) throws GlobalExceptionHandling {
		 customerService.deleteCustomerById(customerid);
		 return "Customer ID Delete Successfully";
		
	}
	
	@PutMapping("/assigncustomer/{cid}/address/{aid}")
	public Customer assignCustomerToAddress(@PathVariable("cid")Integer customerid, @PathVariable("aid")Integer addressId)
	{
		System.out.println("assignCustomerToAddress");
		return customerService.assignCustomerToAddress(customerid,addressId);
	}

}

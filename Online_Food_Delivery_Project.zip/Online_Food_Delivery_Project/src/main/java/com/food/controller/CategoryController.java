package com.food.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.food.dao.Category;
import com.food.error.GlobalExceptionHandling;
import com.food.service.CategoryService;

@RestController
public class CategoryController 
{
	@Autowired
	private CategoryService categoryService;
	
	@PostMapping("/addCategory")
	public ResponseEntity<Category> addCategory(@Valid @RequestBody Category category)
	{
		Category c=categoryService.addCategory(category);
		return new ResponseEntity<Category>(c, HttpStatus.CREATED);	
	}
	
	@PutMapping("/updatecategory/{cid}")
	public Category updatecategory(@PathVariable("cid") Integer categoryId ,@RequestBody Category category) throws GlobalExceptionHandling
	{
		return categoryService.updatecategory(categoryId,category);
	}
	
	@GetMapping("/viewcategory/{cid}")
	public Category viewcategory(@PathVariable("cid") Integer categoryId ) throws GlobalExceptionHandling 
	{
		return categoryService.viewcategory(categoryId);
		
	}
	@DeleteMapping("/removecategory/{cid}")
	public  String removecategory(@PathVariable("cid") Integer categoryId ) throws GlobalExceptionHandling
	{
		 categoryService.removecategory(categoryId);
		return "Category Deleted Successfully";
		
	}
	
	@GetMapping("/viewAll")
    public List<Category> viewAll() {
		return categoryService.viewAll();
		
	}
}
package com.food.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.food.dao.Foodcart;
import com.food.error.GlobalExceptionHandling;
import com.food.service.FoodcartService;

@RestController
public class FoodcartController 
{
	
	@Autowired
	private FoodcartService foodcartService;
	
	@PostMapping("/addFoodcart")
	public Foodcart addFoodcart(@RequestBody Foodcart foodcart) 
	{
		return foodcartService.addFoodcart(foodcart);
		
	}
	
	@DeleteMapping("/removeFoodCart/{fid}")
	public String removeFoodCart(@PathVariable("fid") Integer cartid) throws GlobalExceptionHandling
	{
		foodcartService.removeFoodCart(cartid);
		return "FoodCart Deleted Successfully";
		
	}
	
	@GetMapping("/viewFoodCart/{fid}")
	public Foodcart viewFoodCart(@PathVariable("fid") Integer cartid) throws GlobalExceptionHandling
	{
		return foodcartService.viewFoodCart(cartid);
	}
	
	@PutMapping("/assignFoodcart/{fcid}/Customer/{cid}")
	public Foodcart assignFoodcartToCustomer(@PathVariable("fcid") Integer cartid,@PathVariable("cid") Integer customerid)
	{
		return foodcartService.assignFoodcartToCustomer(cartid,customerid);
	}
	

}

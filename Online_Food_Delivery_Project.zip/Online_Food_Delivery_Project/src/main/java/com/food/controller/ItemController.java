package com.food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.food.dao.Item;
import com.food.error.GlobalExceptionHandling;
import com.food.service.ItemService;


@RestController
public class ItemController {
	@Autowired
	private ItemService itemService;
	
	@PostMapping("/addItem")
	public  ResponseEntity<Item> addItem(@RequestBody Item item)
	{
		Item item1=itemService.addItem(item);
		return new ResponseEntity<Item>(item1, HttpStatus.CREATED);
		
	}
	
	@PutMapping("/updateItemById/{iid}")
	public Item updateItem(@PathVariable ("iid") Integer itemId,@RequestBody Item item) throws GlobalExceptionHandling{
		return itemService.updateItemById(itemId,item);
		
	}
	
	@GetMapping("/viewItemById/{iid}")
	public Item viewItemById(@PathVariable ("iid") Integer itemId) throws GlobalExceptionHandling
	{
		return itemService.viewItemById(itemId);
	}
	
	@DeleteMapping("/deleteItemById/{iid}")
	public String deleteItemById(@PathVariable ("iid") Integer itemId) throws GlobalExceptionHandling{
		itemService.deleteItemById(itemId);
		 return "Item ID Delete Successfully";
		
	}
	
	@GetMapping("/viewAllItems")
    public List<Item> viewAllItems(Integer itemId)
    {
		return itemService.viewAllItems();
    	
    }
	
	@PutMapping("/assignItem/{iid}/Foodcart/{fcid}")
	  public Item assignItemToFoodcart(@PathVariable("iid") Integer itemId,@PathVariable("fcid") Integer cartid)
	  {
		return itemService.assignItemToFoodcart(itemId,cartid);
 	  }
	
	@PutMapping("/assignItem/{iid}/Category/{catid}")
	  public Item assignItemToCategory(@PathVariable("iid") Integer itemId,@PathVariable("catid") Integer categoryId)
	  {
		return itemService.assignItemToCategory(itemId,categoryId);
 	  }
	
	@PutMapping("/assignItem/{iid}/Restaurant/{rid}")
	  public Item assignItemToRestaurant(@PathVariable("iid") Integer itemId,@PathVariable("rid") Integer restaurantId)
	  {
		return itemService.assignItemToRestaurant(itemId,restaurantId);
 	  }
	

}

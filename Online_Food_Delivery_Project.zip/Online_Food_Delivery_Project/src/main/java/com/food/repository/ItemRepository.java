package com.food.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.food.dao.Item;


@Repository
public interface ItemRepository extends JpaRepository<Item, Integer>{

	@Query(value="select * from orderdetails o, customer c,foodcart f, item i where c.customerid=f.customerid AND i.cartid=f.cart_id AND o.cart_id=f.cart_id AND c.customerid=?1", nativeQuery = true)
	List<Item> viewAllOrders(Integer customerid);

	
	
}

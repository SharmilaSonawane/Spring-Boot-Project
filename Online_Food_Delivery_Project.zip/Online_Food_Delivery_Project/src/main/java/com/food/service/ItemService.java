package com.food.service;


import java.util.List;

import com.food.dao.Item;
import com.food.error.GlobalExceptionHandling;

public interface ItemService {

	public Item addItem(Item item);

	public Item updateItemById(Integer itemId, Item item) throws GlobalExceptionHandling;

	public Item viewItemById(Integer itemId) throws GlobalExceptionHandling;

	public void deleteItemById(Integer itemId) throws GlobalExceptionHandling;

	public List<Item> viewAllItems();

	public Item assignItemToFoodcart(Integer itemId, Integer cartid);

	public Item assignItemToCategory(Integer itemId, Integer categoryId);

	public Item assignItemToRestaurant(Integer itemId, Integer restaurantId);

	

}

package com.food.service;

import com.food.dao.Address;

public interface AddressService {

	public Address saveAddress(Address address);

}

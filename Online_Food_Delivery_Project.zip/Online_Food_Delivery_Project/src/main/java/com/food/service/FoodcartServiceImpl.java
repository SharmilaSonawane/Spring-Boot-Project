package com.food.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.food.dao.Customer;
import com.food.dao.Foodcart;

import com.food.error.GlobalExceptionHandling;
import com.food.repository.CustomerRepository;
import com.food.repository.FoodcartRepository;

@Service
public class FoodcartServiceImpl implements FoodcartService{

	@Autowired
	private FoodcartRepository foodcartRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	
	@Override
	public Foodcart addFoodcart(Foodcart foodcart) {
		// TODO Auto-generated method stub
		return foodcartRepository.save(foodcart);
	}
	
	
	
	@Override
	public void removeFoodCart(Integer cartid) throws GlobalExceptionHandling 
	{
		Optional<Foodcart> fc=foodcartRepository.findById(cartid);
		if(!fc.isPresent())
		{
			throw new GlobalExceptionHandling(cartid+" Is Not Present");
		}
		else
		{
			foodcartRepository.deleteById(cartid);
		}
		
		
	}

	
	@Override
	public Foodcart viewFoodCart(Integer cartid) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Foodcart> fc=foodcartRepository.findById(cartid);
		if(!fc.isPresent())
		{
			throw new GlobalExceptionHandling(cartid+" Is Not Present");
		}
		else
		{
			return foodcartRepository.findById(cartid).get();
		}
	}



	@Override
	public Foodcart assignFoodcartToCustomer(Integer cartid, Integer customerid) {
		Foodcart fcart=foodcartRepository.findById(cartid).get();
		Customer cust=customerRepository.findById(customerid).get();
		fcart.assignFoodcartToCustomer(cust);
		return foodcartRepository.save(fcart);
	}
	



}

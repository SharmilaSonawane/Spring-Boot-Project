package com.food.service;

import com.food.dao.Foodcart;
import com.food.error.GlobalExceptionHandling;

public interface FoodcartService {

	public Foodcart addFoodcart(Foodcart foodcart);

	public void removeFoodCart(Integer cartid) throws GlobalExceptionHandling;

	public Foodcart viewFoodCart(Integer cartid) throws GlobalExceptionHandling;

	public Foodcart assignFoodcartToCustomer(Integer cartid, Integer customerid);

	
}

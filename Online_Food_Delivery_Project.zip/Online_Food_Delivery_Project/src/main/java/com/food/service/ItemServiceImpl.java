package com.food.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.dao.Category;
import com.food.dao.Foodcart;
import com.food.dao.Item;
import com.food.dao.Restaurant;
import com.food.error.GlobalExceptionHandling;
import com.food.repository.CategoryRepository;
import com.food.repository.FoodcartRepository;
import com.food.repository.ItemRepository;
import com.food.repository.RestaurantRepository;

@Service
public class ItemServiceImpl implements ItemService{

	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private FoodcartRepository foodcartRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private RestaurantRepository restaurantRepository;
	
	@Override
	public Item addItem(Item item) {
		// TODO Auto-generated method stub
		return itemRepository.save(item);
	}

	@Override
	public Item updateItemById(Integer itemId, Item item) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Item> i=itemRepository.findById(itemId);
		if(!i.isPresent())
		{
			throw new GlobalExceptionHandling(itemId +"Item Id Is Not Present");
		}
		else 
		{
			Item i1=itemRepository.findById(itemId).get();
			if(i1!=null) {
			i1.setItemName(item.getItemName());
			i1.setQuantity(item.getQuantity());
			i1.setCost(item.getCost());
			
			return itemRepository.save(i1);
			}
			return i1;
		}
	}

	@Override
	public Item viewItemById(Integer itemId) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Item> i=itemRepository.findById(itemId);
		if(!i.isPresent()) {
			throw new GlobalExceptionHandling(itemId +"item id is not present");
		}
		else {
			Item i1=itemRepository.findById(itemId).get();
			return i1;
		}
	}

	@Override
	public void deleteItemById(Integer itemId) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Item> i=itemRepository.findById(itemId);
		if(!i.isPresent())
		{
			throw new GlobalExceptionHandling(itemId+" Item Id Is Not Present"); 
		}
		else
		{
			itemRepository.deleteById(itemId);	 
		}
		
	}

	@Override
	public List<Item> viewAllItems() {
		// TODO Auto-generated method stub
		return itemRepository.findAll();
	}

	@Override
	public Item assignItemToFoodcart(Integer itemId, Integer cartid) {
		Item item1=itemRepository.findById(itemId).get();
		Foodcart fcart=foodcartRepository.findById(cartid).get();
		item1.assignItemToFoodcart(fcart);
		return itemRepository.save(item1);
	}

	@Override
	public Item assignItemToCategory(Integer itemId, Integer categoryId) {
		Item item1=itemRepository.findById(itemId).get();
		Category catgy=categoryRepository.findById(categoryId).get();
		item1.assignItemToCategory(catgy);
		return itemRepository.save(item1);
	}

	@Override
	public Item assignItemToRestaurant(Integer itemId, Integer restaurantId) {
		Item item1=itemRepository.findById(itemId).get();
		Restaurant rest=restaurantRepository.findById(restaurantId).get();
		item1.assignItemToRestaurant(rest);
		return itemRepository.save(item1);
	}

	

}

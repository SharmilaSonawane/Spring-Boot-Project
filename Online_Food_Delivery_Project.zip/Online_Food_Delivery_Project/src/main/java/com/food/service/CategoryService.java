package com.food.service;

import java.util.List;

import javax.validation.Valid;

import com.food.dao.Category;
import com.food.error.GlobalExceptionHandling;

public interface CategoryService {

	public Category addCategory(@Valid Category category);

	public Category updatecategory(Integer categoryId,Category category) throws GlobalExceptionHandling;

	public Category viewcategory(Integer categoryId) throws GlobalExceptionHandling;

	public void removecategory(Integer categoryId) throws GlobalExceptionHandling;

	public List<Category> viewAll();

	

}

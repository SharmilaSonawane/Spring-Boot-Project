package com.food.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.dao.Category;
import com.food.error.GlobalExceptionHandling;
import com.food.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public Category addCategory(@Valid Category category) {
		// TODO Auto-generated method stub
		return categoryRepository.save(category);
	}
	

	
	@Override
	public List<Category> viewAll() {
		// TODO Auto-generated method stub
		
		return categoryRepository.findAll();
	}
	@Override
	public  void removecategory(Integer categoryId) throws GlobalExceptionHandling {
		Optional<Category> catg1=categoryRepository.findById(categoryId);
		if(!catg1.isPresent()) {
			throw new GlobalExceptionHandling("category id "+categoryId+"is not exists");
		}else 
		{
			categoryRepository.deleteById(categoryId);
		}
		
	}

	@Override
	public Category viewcategory(Integer categoryId) throws GlobalExceptionHandling {
		Optional<Category> catg1=categoryRepository.findById(categoryId);
		if(!catg1.isPresent()) {
			throw new GlobalExceptionHandling("category id "+categoryId+"is not exists");
		}else 
		{
			Category catg2=categoryRepository.findById(categoryId).get();
		     return catg2;
		}     
	}
	@Override
	public Category updatecategory(Integer categoryId,Category category) throws GlobalExceptionHandling {
		Optional<Category> catg1=categoryRepository.findById(categoryId);
		if(!catg1.isPresent()) 
		{
			throw new GlobalExceptionHandling("category id "+categoryId+"is not exists");
		}
		else 
		{
			Category catg2=categoryRepository.findById(categoryId).get();
			if(catg2!=null) {
				catg2.setCategoryName(category.getCategoryName());
				return categoryRepository.save(catg2);
			}
			return catg2;
		}
	}
	
	
	

}
